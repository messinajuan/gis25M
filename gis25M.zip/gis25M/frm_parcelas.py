﻿    # encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2018 Juan Messina
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

import os
from PyQt5.QtWidgets import QMessageBox, QWidget
from PyQt5 import uic

DialogBase, DialogType = uic.loadUiType(os.path.join(os.path.dirname(__file__),'frm_parcelas.ui'))

class frmParcelas(DialogType, DialogBase):

    def __init__(self, tipo_usuario, mapCanvas, conn, obj, datos):
        super().__init__()
        self.setupUi(self)
        self.setFixedSize(self.size())
        self.tipo_usuario = tipo_usuario
        self.mapCanvas = mapCanvas
        self.conn = conn
        self.obj = obj
        self.geoname = datos[1]
        self.tabWidget.clear()
        if self.geoname != 0:
            cnn = self.conn
            cursor = cnn.cursor()
            cursor.execute("SELECT row_number, geoname, pda, circuns, seccion, chacra_nro, chacra_let, quinta_nro, quinta_let, fraccion_nro, fraccion_let, manzana_nro, manzana_let, parcela_nro, parcela_let, subparcela, nro_inmueble, tipo, desc_tipo, contribuyente, sup_terreno, val_fiscal, medidor_luz, partida_provincial, serv_publicos, red_vial FROM mapparcelas WHERE geoname=" + str(self.geoname))
            #convierto el cursor en array
            self.parcelas = tuple(cursor)
            cursor.close()
            for i in range (0, len(self.parcelas)):
                self.tabWidget.addTab(QWidget(), str(i+1))

            if len(self.parcelas)>0:
                self.elegir_tab(0)
        else:
            self.tabWidget.addTab(QWidget(), '1')

        self.tabWidget.currentChanged.connect(self.elegir_tab)
        self.cmdAceptar.clicked.connect(self.aceptar)
        self.cmdSalir.clicked.connect(self.salir)

    def elegir_tab(self, id):
        self.lblRowId.setText(str(self.parcelas[id][0]))
        self.lblGeoname.setText(str(self.parcelas[id][1]))
        self.txtPartida.setText(self.parcelas[id][2])
        self.txtCircunscripcion.setText(str(self.parcelas[id][3]))
        self.txtSeccion.setText(self.parcelas[id][4])
        self.txtChacra.setText(str(self.parcelas[id][5]))
        self.txtChacra_2.setText(self.parcelas[id][6])
        self.txtQuinta.setText(str(self.parcelas[id][7]))
        self.txtQuinta_2.setText(self.parcelas[id][8])
        self.txtFraccion.setText(str(self.parcelas[id][9]))
        self.txtFraccion_2.setText(self.parcelas[id][10])
        self.txtManzana.setText(str(self.parcelas[id][11]))
        self.txtManzana_2.setText(self.parcelas[id][12])
        self.txtParcela.setText(str(self.parcelas[id][13]))
        self.txtParcela_2.setText(self.parcelas[id][14])
        self.txtSubparcela.setText(self.parcelas[id][15])
        self.lblNroInmueble.setText(str(self.parcelas[id][16]))
        #id_tipo self.parcelas[id][22]
        self.lblTipo.setText(self.parcelas[id][18])
        self.lblContribuyente.setText(self.parcelas[id][19])
        self.lblSuperficie.setText(str(self.parcelas[id][20]))
        self.lblValuacion.setText(str(self.parcelas[id][21]))
        #medidor_luz self.parcelas[id][22]
        self.lblPartidaProvincial.setText(self.parcelas[id][23])
        #serv_publicos self.parcelas[id][24]
        #red_vial self.parcelas[id][25]

    def aceptar(self):
        if self.txtPartida.text()=="":
            QMessageBox.warning(None, 'Gis 25 de Mayo', "Debe cargar una Partida en la Parcela")
            return
        obj = ''
        if self.geoname == 0: #Si es nueva -> INSERT
            cnn = self.conn
            cursor = cnn.cursor()
            cursor.execute("SELECT geoname FROM parcelas WHERE pda='" + self.txtPartida.text() + "'")
            parcelas = tuple(cursor)
            cursor.close()
            if len(parcelas)>0:
                QMessageBox.warning(None, 'Gis 25 de Mayo', "Ess partida ya existe en otra parcela !")
                return
            cursor = cnn.cursor()
            cursor.execute("SELECT MAX(geoname) FROM parcelas")
            iid = tuple(cursor)
            id = iid[0][0] + 1
            cursor.close()
            obj = "geometry::STGeomFromText(" + "'" + self.obj.geometry().asWkt() + "',22195)"
            str_valores = str(id) + ", "
            str_valores = str_valores + "'" + self.txtPartida.text() + "', "
            str_valores = str_valores + obj
            try:
                cursor = cnn.cursor()
                cursor.execute("INSERT INTO Parcelas (geoname, pda, obj) VALUES (" + str_valores + ")")
                cnn.commit()
            except:
                cnn.rollback()
                QMessageBox.critical(None, 'Gis 25 de Mayo', 'No se pudo insertar en la Base de Datos')

        else: #Si cambio algo -> UPDATE
            cnn = self.conn
            cursor = cnn.cursor()
            try:
                cursor.execute("UPDATE Parcelas SET pda='" + self.txtPartida.text() + "' WHERE Geoname=" + str(self.geoname))
                cnn.commit()
            except:
                cnn.rollback()
                QMessageBox.critical(None, 'Gis 25 de Mayo', 'No se pudo actualizar la Base de Datos')
        self.close()

    def salir(self):
        self.close()
