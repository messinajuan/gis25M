# encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2024 Municipalidad de 25 de Mayo
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

from PyQt5 import QtGui
from PyQt5.QtWidgets import QMessageBox, QInputDialog
from qgis.gui import QgsMapTool
from qgis.core import QgsRectangle, QgsFeatureRequest, QgsMapLayerType
from qgis.core import QgsProject

import os

#from .herr_nodo import herrNodo
#from .herr_linea import herrLinea
#from .herr_poste import herrPoste
#from .herr_area import herrArea
from .herr_parcela import herrParcela
from .herr_zoom import herrZoom

#esta es la direccion del proyecto
basepath = os.path.dirname(os.path.realpath(__file__))

class herrSeleccion(QgsMapTool):
    def __init__(self, proyecto, tipo_usuario, mapCanvas, iface, conn):
        QgsMapTool.__init__(self, mapCanvas)
        self.proyecto = proyecto
        self.tipo_usuario = tipo_usuario
        self.mapCanvas = mapCanvas
        self.iface = iface
        self.conn = conn
        self.clipboard=[]
        self.tecla=''

    def keyPressEvent(self, event):
        if str(event.key()) == '16777249':
            self.tecla = 'Ctrl'

    def keyReleaseEvent(self, event):
        self.tecla=''
        if str(event.key()) == '16777223':
            self.h_borrar() #copiado textualmente de energis5.py

    def lyr_visible(self, layer):
        layer_tree_root = QgsProject.instance().layerTreeRoot()
        layer_tree_layer = layer_tree_root.findLayer(layer)
        return layer_tree_layer.isVisible()

    def canvasPressEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        self.point = self.mapCanvas.getCoordinateTransform().toMapCoordinates(x, y)

        #si no tengo apretada Ctrl borro la seleccion anterior
        if self.tecla != 'Ctrl':
            n = self.mapCanvas.layerCount()
            layers = [self.mapCanvas.layer(i) for i in range(n)]
            for lyr in layers:
                if lyr.type() == QgsMapLayerType.VectorLayer: #si es una capa vectorial
                    lyr.removeSelection()

        n = self.mapCanvas.layerCount()
        layers = [self.mapCanvas.layer(i) for i in range(n)]
        #hacemos que se busque en las capas que queremos !!!
        for lyr in layers:
            if self.lyr_visible(lyr) is True:
                if lyr.type() == QgsMapLayerType.VectorLayer: #si es una capa vectorial
                    #QMessageBox.information(None, 'Gis 25 de Mayo', lyr.name())
                    #if lyr.name()[:6] == 'Lineas' or lyr.name()[:5] == 'Nodos' or lyr.name()[:6] == 'Postes' or lyr.name() == 'Areas' or lyr.name() == 'Parcelas' or lyr.name() == 'Anotaciones':
                    if lyr.name() == 'Parcelas':
                        #QMessageBox.information(None, 'Gis 25 de Mayo', lyr.name())
                        width = 5 * self.mapCanvas.mapUnitsPerPixel()
                        rect = QgsRectangle(self.point.x() - width, self.point.y() - width, self.point.x() + width, self.point.y() + width)
                        #rect = self.mapCanvas.mapRenderer().mapToLayerCoordinates(lyr, rect)
                        int = QgsFeatureRequest().setFilterRect(rect).setFlags(QgsFeatureRequest.ExactIntersect)
                        ftrs = lyr.getFeatures(int)
                        for ftr in ftrs:
                            #QMessageBox.information(None, 'Gis 25 de Mayo', ftr.geometry().asWkt())
                            #QMessageBox.information(None, 'Gis 25 de Mayo', str(ftr.id()))
                            b_seleccionado = False
                            for i in lyr.selectedFeatures():
                                if i.id() == ftr.id():
                                    b_seleccionado = True

                            if b_seleccionado == True:
                                seleccion = []
                                for i in lyr.selectedFeatures():
                                    seleccion.append(i.id())
                                seleccion.remove(ftr.id())
                                lyr.removeSelection()
                                lyr.select(seleccion)
                                return
                            else:
                                lyr.select(ftr.id())
                                return

    def canvasDoubleClickEvent(self, event):
        #Get the click
        x = event.pos().x()
        y = event.pos().y()
        self.point = self.mapCanvas.getCoordinateTransform().toMapCoordinates(x, y)
        n = self.mapCanvas.layerCount()
        layers = [self.mapCanvas.layer(i) for i in range(n)]
        #hacemos que se busque en las capas que queremos !!!
        for lyr in layers:
            if lyr.type() == QgsMapLayerType.VectorLayer: #si es una capa vectorial
                if self.lyr_visible(lyr) is True:
                    #if (lyr.name()[:6] == 'Lineas') or (lyr.name()[:5] == 'Nodos') or lyr.name()[:6] == 'Postes' or lyr.name() == 'Areas' or lyr.name() == 'Parcelas':
                    if lyr.name() == 'Parcelas':
                        #QMessageBox.information(None, 'Gis 25 de Mayo', str(lyr.name()))
                        width = 6 * self.mapCanvas.mapUnitsPerPixel()
                        rect = QgsRectangle(self.point.x() - width, self.point.y() - width, self.point.x() + width, self.point.y() + width)
                        int = QgsFeatureRequest().setFilterRect(rect).setFlags(QgsFeatureRequest.ExactIntersect)
                        ftrs = lyr.getFeatures(int)
                        for ftr in ftrs:
                            lyr.select(ftr.id())
                            #if lyr.name()[:5] == 'Nodos':
                            #    str_tension = lyr.name() [6 - len(lyr.name()):]
                            #    if str_tension.strip() == 'Proyectos':
                            #        from .frm_nodos_proyecto import frmNodosProyecto
                            #        self.dialogo = frmNodosProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, ftr.id(), 0, event.pos())
                            #        self.dialogo.show()
                            #        return
                            #    else:
                            #        from .frm_nodos import frmNodos
                            #        self.dialogo = frmNodos(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, ftr.id(), 0, event.pos())
                            #        self.dialogo.show()
                            #        return
                            #if lyr.name()[:6] == 'Lineas':
                            #    str_tension = lyr.name() [7 - len(lyr.name()):]
                            #    if str_tension.strip() == 'Proyectos':
                            #        from .frm_lineas_proyecto import frmLineasProyecto
                            #        self.dialogo = frmLineasProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, 0, 0, ftr.geometry().length(), None, ftr.id())
                            #        self.dialogo.show()
                            #        return
                            #    else:
                            #        from .frm_lineas import frmLineas
                            #        self.dialogo = frmLineas(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, 0, 0, ftr.geometry().length(), None, ftr.id())
                            #        self.dialogo.show()
                            #        return
                            #if lyr.name()[:6] == 'Postes':
                            #    str_tension = lyr.name() [7 - len(lyr.name()):]
                            #    if str_tension.strip() == 'Proyectos':
                            #        from .frm_postes_proyecto import frmPostesProyecto
                            #        self.dialogo = frmPostesProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, ftr.id(), 0, 0, 0, event.pos())
                            #        self.dialogo.show()
                            #        return
                            #    else:
                            #        from .frm_postes import frmPostes
                            #        self.dialogo = frmPostes(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, ftr.id(), 0, 0, 0, event.pos())
                            #        self.dialogo.show()
                            #        return
                            #if lyr.name() == 'Areas':
                            #    from .frm_areas import frmAreas
                            #    self.dialogo = frmAreas(self.tipo_usuario, self.mapCanvas, self.conn, '', ftr.id())
                            #    self.dialogo.show()
                            #    return
                            if lyr.name() == 'Parcelas':
                                from .frm_parcelas import frmParcelas
                                self.dialogo = frmParcelas(self.tipo_usuario, self.mapCanvas, self.conn, '', list(ftr.attributes()))
                                self.dialogo.show()
                                return


    def nodo(self):
        #tool = herrNodo(self.proyecto, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        #self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punNodo = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punNodo.setMask(punNodo.mask())
        curNodo = QtGui.QCursor(punNodo)
        self.mapCanvas.setCursor(curNodo)
        pass
        
    def linea(self):
        #tool = herrLinea(self.proyecto, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        #self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.mapCanvas.setCursor(curLinea)
        pass
               
    def poste(self):
        #tool = herrPoste(self.proyecto, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        #self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punNodo = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punNodo.setMask(punNodo.mask())
        curNodo = QtGui.QCursor(punNodo)
        self.mapCanvas.setCursor(curNodo)
        pass

    def area(self):
        #QMessageBox.information(None, 'h_nodo', str(tension))
        #tool = herrArea(self.tipo_usuario, self.iface.mapCanvas(), self.conn)
        #self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.mapCanvas.setCursor(curLinea)
        pass

    def parcela(self):
        #QMessageBox.information(None, 'h_nodo', str(tension))
        tool = herrParcela(self.tipo_usuario, self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.mapCanvas.setCursor(curLinea)
        pass

    def insertar_postes(self):
        dist, p2, segmento, s = self.ftr.geometry().closestSegmentWithContext(self.point)
        i=0
        for v in self.ftr.geometry().vertices():
            i=i+1
            if i==segmento:
                p1=v
            if i==segmento+1:
                p2=v

        str_tension = self.capa.name() [7 - len(self.capa.name()):]
        from .frm_insertar_postes import frmInsertarPostes
        self.dialogo = frmInsertarPostes(self.proyecto, self.mapCanvas, self.conn, str_tension, self.ftr.id(), p1, p2)
        self.dialogo.show()
        pass

    def editar(self):
        #QMessageBox.information(None, 'Gis 25 de Mayo', str(self.ftr))
        if self.capa.name()[:5] == 'Nodos':
            str_tension = self.capa.name() [6 - len(self.capa.name()):]

            if str_tension.strip() == 'Proyectos':
                from .frm_nodos_proyecto import frmNodosProyecto
                self.dialogo = frmNodosProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, self.ftr.id(), 0, None)
                self.dialogo.show()
                return
            else:
                from .frm_nodos import frmNodos
                self.dialogo = frmNodos(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, self.ftr.id(), 0, None)
                self.dialogo.show()
                return

        if self.capa.name()[:6] == 'Lineas':
            str_tension = self.capa.name() [7 - len(self.capa.name()):]

            if str_tension.strip() == 'Proyectos':
                from .frm_lineas_proyecto import frmLineasProyecto
                self.dialogo = frmLineasProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, 0, 0, self.ftr.geometry().length(), None, self.ftr.id())
                self.dialogo.show()
                return
            else:
                from .frm_lineas import frmLineas
                self.dialogo = frmLineas(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, 0, 0, self.ftr.geometry().length(), None, self.ftr.id())
                self.dialogo.show()
                return

        if self.capa.name()[:6] == 'Postes':
            str_tension = self.capa.name() [7 - len(self.capa.name()):]
            if self.capa.name() == 'Postes Proyectos':
                from .frm_postes_proyecto import frmPostesProyecto
                self.dialogo = frmPostesProyecto(self.proyecto, self.tipo_usuario, self.mapCanvas, self.conn, str_tension, self.ftr.id(), 0, 0, 0, None)
                self.dialogo.show()
            else:
                from .frm_postes import frmPostes
                self.dialogo = frmPostes(self.tipo_usuario, self.mapCanvas, self.conn, str_tension, self.ftr.id(), 0, 0, 0, None)
                self.dialogo.show()
                return

        if self.capa.name() == 'Areas':
            from .frm_areas import frmAreas
            self.dialogo = frmAreas(self.tipo_usuario, self.mapCanvas, self.conn, '', self.ftr.id())
            self.dialogo.show()
            return

        if self.capa.name() == 'Parcelas':
            from .frm_parcelas import frmParcelas
            self.dialogo = frmParcelas(self.tipo_usuario, self.mapCanvas, self.conn, '', self.ftr.id())
            self.dialogo.show()
            return

    def editar_anotacion(self):
        etiqueta = ''
        text, ok = QInputDialog.getText(self.mapCanvas, 'Ingreso de Datos', 'Ingrese Nueva Anotación', text=etiqueta)
        if ok:
            etiqueta=str(text)
        else:
            return
        if etiqueta=='':
            return
        cnn = self.conn
        cursor = cnn.cursor()
        try:
            cursor.execute("UPDATE Anotaciones SET etiqueta = '" + etiqueta + "' WHERE geoname=" + str(self.ftr.id()))
            cnn.commit()
            self.capa.triggerRepaint()
        except:
            cnn.rollback()
            QMessageBox.critical(None, 'Gis 25 de Mayo', 'No se pudo editar')

    def operar_seccionador(self):
        from .frm_operar_seccionador import frmOperarSeccionador
        self.dialogo = frmOperarSeccionador(self.conn, self.ftr.id(), self.elmt, self.estado, self.capa)
        self.dialogo.show()
        pass

    def cortar(self):
        reply = QMessageBox.question(None, 'Gis 25 de Mayo', 'Desea cortar atributos del elemento ' + str(self.ftr.id()) + ' de la capa ' + self.capa.name() + ' ?', QMessageBox.Yes, QMessageBox.No)
        if reply == QMessageBox.No:
            return
        self.clipboard = []
        self.clipboard.append("cortar")
        self.clipboard.append(self.capa)
        self.clipboard.append(self.ftr)

    def copiar(self):
        #reply = QMessageBox.question(None, 'Gis 25 de Mayo', 'Desea copiar atributos del elemento ' + str(self.ftr.id()) + ' de la capa ' + self.capa.name() + ' ?', QMessageBox.Yes, QMessageBox.No)
        #if reply == QMessageBox.No:
        #    return
        self.clipboard = []
        self.clipboard.append("copiar")
        self.clipboard.append(self.capa)
        self.clipboard.append(self.ftr)

    def pegar(self):
        reply = QMessageBox.question(None, 'Gis 25 de Mayo', 'Desea pegar los atributos al elemento ' + str(self.ftr.id()) + ' de la capa ' + self.capa.name() + ' ?', QMessageBox.Yes, QMessageBox.No)
        if reply == QMessageBox.No:
            return
        str_operacion = self.clipboard[0]
        capa = self.clipboard[1]
        elemento = self.clipboard[2]

        cnn = self.conn
        if capa.name()[:5] == 'Nodos':
            cursor = cnn.cursor()
            cursor.execute("SELECT ISNULL(nombre, ''), ISNULL(descripcion, ''), elmt, ISNULL(val1, ''), ISNULL(val2, ''), ISNULL(val3, ''), ISNULL(val4, ''), ISNULL(val5, ''), modificacion, estado, ISNULL(uucc, '') FROM Nodos WHERE Geoname=" + str(elemento.id()))
            #convierto el cursor en array
            rst = tuple(cursor)
            cursor.close()

            str_update = "nombre='" + rst[0][0] + "'"
            str_update = str_update + ", descripcion='" + rst[0][1] + "'"
            str_update = str_update + ", elmt=" + str(rst[0][2])
            str_update = str_update + ", val1='" + rst[0][3] + "'"
            str_update = str_update + ", val2='" + rst[0][4] + "'"
            str_update = str_update + ", val3='" + rst[0][5] + "'"
            str_update = str_update + ", val4='" + rst[0][6] + "'"
            str_update = str_update + ", val5='" + rst[0][7] + "'"
            str_update = str_update + ", modificacion='" + str(rst[0][8]).replace('-','') + "'"
            str_update = str_update + ", estado=" + str(rst[0][9])
            str_update = str_update + ", uucc='" + rst[0][10] + "'"

            cursor = cnn.cursor()
            try:
                cursor.execute("UPDATE Nodos SET " + str_update + " WHERE Geoname=" + str(self.ftr.id()))
                cnn.commit()
            except:
                cnn.rollback()
                QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudo actualizar !")
            QMessageBox.information(None, '', "Pegado ! Falta ver mnNodos")

            if rst[0][2] == 6:
                if str_operacion == "Copiar":
                    QMessageBox.information(None, '', "No se moverán los usuarios del suministro, quedarán en el nodo origen")
                else:
                    cursor = cnn.cursor()
                    try:
                        cursor.execute("UPDATE suministros SET id_nodo=" + str(self.ftr.id()) + " WHERE id_nodo=" + str(elemento.id()))
                        cnn.commit()
                    except:
                        cnn.rollback()
                        QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudo actualizar !")

            if str_operacion == "Cortar":
                cursor = cnn.cursor()
                try:
                    cursor.execute("UPDATE Nodos SET Nombre='', Descripcion='', elmt=0, Val1='',Val2='',Val3='',Val4='',Val5='', estado=0, uucc='' WHERE geoname=" + str(elemento.id()))
                    cnn.commit()
                except:
                    cnn.rollback()
                    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudo actualizar !")
                QMessageBox.information(None, '', "Falta ver mnNodos")

        elif capa.name()[:6] == 'Lineas':
            cursor = cnn.cursor()
            cursor.execute("SELECT elmt, fase, modificacion, exp, disposicion, conservacion, ternas, acometida, uucc FROM Lineas WHERE geoname=" + str(elemento.id()))
            #convierto el cursor en array
            rst = tuple(cursor)
            cursor.close()

            str_update = "elmt=" + str(rst[0][0])
            str_update = str_update + ", fase='" + rst[0][1] + "'"
            str_update = str_update + ", modificacion='" + str(rst[0][2]).replace('-','') + "'"
            str_update = str_update + ", exp='" + rst[0][3] + "'"
            str_update = str_update + ", disposicion='" + rst[0][4] + "'"
            str_update = str_update + ", conservacion='" + rst[0][5] + "'"
            str_update = str_update + ", ternas='" + rst[0][6] + "'"
            str_update = str_update + ", acometida=" + str(rst[0][7])
            str_update = str_update + ", uucc='" + rst[0][8] + "'"

            cursor = cnn.cursor()
            cursor.execute("UPDATE Lineas SET " + str_update + " WHERE geoname=" + str(self.ftr.id()))
            cnn.commit()
            QMessageBox.information(None, '', "Pegado ! Falta ver mnLineas")

        elif capa.name()[:6] == 'Postes':
            cursor = cnn.cursor()
            cursor.execute("SELECT elmt, estructura, rienda, altura, modificacion, ISNULL(descripcion, ''), profundidad, tipo, aislacion, fundacion, comparte, ternas, PAT, descargadores FROM Postes WHERE Geoname=" + str(elemento.id()))
            #convierto el cursor en array
            rst = tuple(cursor)
            cursor.close()

            str_update = "elmt=" + str(rst[0][0])
            str_update = str_update + ", estructura=" + str(rst[0][1])
            str_update = str_update + ", rienda=" + str(rst[0][2])
            str_update = str_update + ", altura=" + str(rst[0][3])
            str_update = str_update + ", modificacion='" + str(rst[0][4]).replace('-','') + "'"
            str_update = str_update + ", descripcion='" + rst[0][5] + "'"
            str_update = str_update + ", profundidad='" + rst[0][6] + "'"
            str_update = str_update + ", tipo='" + rst[0][7] + "'"
            str_update = str_update + ", aislacion='" + rst[0][8] + "'"
            str_update = str_update + ", fundacion=" + str(rst[0][9])
            str_update = str_update + ", comparte='" + rst[0][10] + "'"
            str_update = str_update + ", ternas='" + rst[0][11] + "'"
            str_update = str_update + ", PAT=" + str(rst[0][12])
            str_update = str_update + ", descargadores=" + str(rst[0][13])

            cursor = cnn.cursor()
            try:
                cursor.execute("UPDATE Postes SET " + str_update + " WHERE geoname=" + str(self.ftr.id()))
                cnn.commit()
            except:
                cnn.rollback()
                QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudo actualizar !")
            QMessageBox.information(None, '', "Pegado !")

        capa.triggerRepaint()

    def borrar(self):
        reply = QMessageBox.question(None, 'Gis 25 de Mayo', 'Desea borrar de capa ' + self.capa.name() + ' ?', QMessageBox.Yes, QMessageBox.No)
        if reply == QMessageBox.No:
            return

        #if self.capa.name()[:5] == 'Nodos':
        #    cnn = self.conn
        #    cursor = cnn.cursor()
        #    try:
        #        cursor.execute("DELETE FROM Nodos WHERE geoname=" + str(self.ftr.id()))
        #        cnn.commit()
        #    except:
        #        cnn.rollback()
        #        QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudo actualizar !")
        #    self.capa.triggerRepaint()
        #    return

        #if self.capa.name()[:6] == 'Lineas':
        #    cnn = self.conn
        #    cursor = cnn.cursor()
        #    try:
        #        cursor.execute("DELETE FROM Lineas WHERE geoname=" + str(self.ftr.id()))
        #        cnn.commit()
        #    except:
        #        cnn.rollback()
        #        QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Lineas !")
        #    self.capa.triggerRepaint()
        #    return

        #if self.capa.name()[:6] == 'Postes':
        #    cnn = self.conn
        #    cursor = cnn.cursor()
        #    try:
        #        cursor.execute("DELETE FROM Postes WHERE geoname=" + str(self.ftr.id()))
        #        cnn.commit()
        #    except:
        #        cnn.rollback()
        #        QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Postes !")
        #    self.capa.triggerRepaint()
        #    return

        #if self.capa.name() == 'Areas':
        #    cnn = self.conn
        #    cursor = cnn.cursor()
        #    try:
        #        cursor.execute("DELETE FROM Areas WHERE geoname=" + str(self.ftr.id()))
        #        cnn.commit()
        #    except:
        #        cnn.rollback()
        #    self.capa.triggerRepaint()
        #    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Areas !")
        #    return

        if self.capa.name() == 'Parcelas':
            cnn = self.conn
            cursor = cnn.cursor()
            try:
                cursor.execute("DELETE FROM Parcelas WHERE geoname=" + str(self.ftr.id()))
                cnn.commit()
            except:
                cnn.rollback()
                QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Parcelas !")
            self.capa.triggerRepaint()
            return

        #if self.capa.name() == 'Anotaciones':
        #    cnn = self.conn
        #    cursor = cnn.cursor()
        #    try:
        #        cursor.execute("DELETE FROM Anotaciones WHERE geoname=" + str(self.ftr.id()))
        #        cnn.commit()
        #    except:
        #        cnn.rollback()
        #        QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Anotaciones !")
        #    self.capa.triggerRepaint()
        #    return

    def zoomIn(self):
        #QMessageBox.information(None, '', "zoomin")
        tool = herrZoom(self.iface.mapCanvas(), 'ZoomIn')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_zoom_in.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.mapCanvas.setCursor(curZoom)
        pass

    def zoomOut(self):
        #QMessageBox.information(None, '', "zoomout")
        tool = herrZoom(self.iface.mapCanvas(), 'ZoomOut')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_zoom_out.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.mapCanvas.setCursor(curZoom)
        pass
        
    def pan(self):
        #QMessageBox.information(None, 'h_nodo', "pan")
        tool = herrZoom(self.iface.mapCanvas(), 'Pan')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_pan.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.mapCanvas.setCursor(curZoom)
        pass
