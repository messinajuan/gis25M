﻿ # encoding: utf-8
#-----------------------------------------------------------
# Copyright (C) 2024 Municipalidad de 25 de Mayo
#-----------------------------------------------------------
# Licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#---------------------------------------------------------------------

import os
import pyodbc
import psycopg2
from PyQt5 import QtWidgets, QtGui
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QMessageBox, QAction, QToolBar
from PyQt5.QtCore import Qt
from qgis.core import QgsProject

#esta es la direccion del proyecto
basepath = os.path.dirname(os.path.realpath(__file__))

class gis25M(object):

    def __init__(self, iface):
        #da acceso a la interfaz QGIS
        self.iface = iface
        self.mapCanvas = iface.mapCanvas()
        self.utils = iface.mapCanvas().snappingUtils()
        # create action that will start plugin configuration
        self.gis25m_action = QAction(QIcon(os.path.join(basepath,"icons", 'gis25M.ico')), "gis25M", self.iface.mainWindow())
        self.gis25m_action.setWhatsThis("")
        self.gis25m_action.setStatusTip("Detenido")
        self.gis25m_action.triggered.connect(self.run)
        # add toolbar button and menu item
        self.iface.addToolBarIcon(self.gis25m_action)
        self.iface.addPluginToMenu("gis25M", self.gis25m_action)
        self.conn = None
        self.modelo=""
        self.id_usuario_sistema = 0
        self.tipo_usuario = 4

    def initGui(self):
        #llamado cuando se carga el complemento
        #La versión cambiará cuando cambie la db
        self.version = '1.0.0'

    def run(self):

        if self.gis25m_action.statusTip()=="Detenido":
            self.gis25m_action.setStatusTip("Iniciado")            
            str_conexion = str(self.gis25m_action.whatsThis())
            self.nombre_modelo = QgsProject.instance().title()
        else:
            self.gis25m_action.setStatusTip("Detenido")
            str_conexion = ""

        if self.gis25m_action.statusTip()=='Iniciado':
            self.gis25m_action.setStatusTip('Conectando a la Base de Datos')
            try:
                self.conn = psycopg2.connect(str_conexion)
                self.gis25m_action.setStatusTip('Conectado a la Base de Datos')
            except:
                QMessageBox.critical(None, 'Gis 25 de Mayo', 'No se pudo conectar la BD gis')
                self.gis25m_action.setStatusTip('Desconectado')
                str_conexion = ""
                return
        else:
            self.gis25m_action.setStatusTip('Desconectado')
            try:
                self.toolbar_h.deleteLater()
                self.toolbar_v.deleteLater()
                main_window = self.iface.mainWindow()
            except:
                pass

        if self.gis25m_action.statusTip()=='Conectado a la Base de Datos':
            #Creo barras de herramientas
            self.actions = []
            self.menu = ('25Mgis')
            self.toolbar_h = self.iface.addToolBar('25Mgis Dibujo')
            self.toolbar_v = QToolBar('25Mgis Busqueda')
            self.toolbar_v.setOrientation(Qt.Vertical)
            self.iface.mainWindow().addToolBar(Qt.LeftToolBarArea, self.toolbar_v)
            #------------------------------------------
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_sql.png'), 'Actualizar Datos', self.actualizar_rafam, True, False, True, True, None, None, self.iface.mainWindow())
            self.toolbar_h.addSeparator()
            #------------------------------------------
            inicio = QtWidgets.QPushButton("Menú")
            self.toolbar_h.addWidget(inicio)
            menu = QtWidgets.QMenu()
            #------------------------------------------
            self.m_listados = menu.addMenu('Listados')
            #------------------------------------------
            #action = QAction(QIcon(os.path.join(basepath,"icons", 'img_listados.png')), 'Seccionadores', self.iface.mainWindow())
            #action.triggered.connect(self.listado_seccionadores)
            #self.m_listados.addAction(action)
            #------------------------------------------
            #action = QAction(QIcon(os.path.join(basepath,"icons", 'img_listados.png')), 'Postes', self.iface.mainWindow())
            #action.triggered.connect(self.listado_postes)
            #self.m_listados.addAction(action)
            #------------------------------------------
            inicio.setMenu(menu)
            #------------------------------------------
            self.toolbar_h.addSeparator()
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_seleccion.png'), 'Selección', self.h_seleccion, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_seleccion_aleatoria.png'), 'Selección por Area', self.h_seleccion_aleatoria, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_seleccion_circular.png'), 'Selección Circular', self.h_seleccion_circular, True, False, True, True, None, None, self.iface.mainWindow())
            self.toolbar_h.addSeparator()
            #self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_nodo.png'), 'Nodo', self.h_nodo, True, False, True, True, None, None, self.iface.mainWindow())
            #self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_linea.png'), 'Linea', self.h_linea, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_parcela.png'), 'Parcelas', self.h_parcela, True, False, True, True, None, None, self.iface.mainWindow())
            #boton desplegable
            self.tool_button = QtWidgets.QToolButton()
            self.tool_button.setText("Vertices")
            self.tool_button.setIcon(QIcon(os.path.join(basepath,"icons", 'img_agregar_vertice.png')))
            menu_boton = QtWidgets.QMenu()
            self.vertices_1 = QAction(QIcon(os.path.join(basepath,"icons", 'img_agregar_vertice.png')), 'Agregar Vertice', self.toolbar_h)
            self.vertices_2 = QAction(QIcon(os.path.join(basepath,"icons", 'img_quitar_vertice.png')), 'Borrar Vertice', self.toolbar_h)
            self.vertices_1.triggered.connect(self.h_agregar_vertice)
            self.vertices_2.triggered.connect(self.h_quitar_vertice)
            menu_boton.addAction(self.vertices_1)
            menu_boton.addAction(self.vertices_2)
            self.tool_button.setMenu(menu_boton)
            self.tool_button.setPopupMode(QtWidgets.QToolButton.InstantPopup)
            self.toolbar_h.addWidget(self.tool_button)
            #self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_poste.png'), 'Poste', self.h_poste, True, False, True, True, None, None, self.iface.mainWindow())
            #self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_girar.png'), 'Girar', self.h_girar, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_mover.png'), 'Mover', self.h_mover, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_rotar.png'), 'Rotar', self.h_rotar, True, False, True, True, None, None, self.iface.mainWindow())
            self.toolbar_h.addSeparator()
            self.toolbar_h.addSeparator()
            self.agregar_herramienta(self.toolbar_h, os.path.join(basepath,"icons", 'img_borrar.png'), 'Borrar', self.h_borrar, True, False, True, True, None, None, self.iface.mainWindow())
            #--------------------------------------------------
            #self.toolbar_h.addSeparator()
            #--------------------------------------------------
            self.agregar_herramienta(self.toolbar_v, os.path.join(basepath,"icons", 'img_zoom_in.png'), 'Zoom In', self.h_zoomIn, True, False, True, True, None, None, self.iface.mainWindow())
            #self.agregar_herramienta(self.toolbar_v, os.path.join(basepath,"icons", 'img_zoom_out.png'), 'Zoom Out', self.h_zoomOut, True, False, True, True, None, None, self.iface.mainWindow())
            self.agregar_herramienta(self.toolbar_v, os.path.join(basepath,"icons", 'img_pan.png'), 'Pan', self.h_Pan, True, False, True, True, None, None, self.iface.mainWindow())
            self.toolbar_v.addSeparator()
            self.agregar_herramienta(self.toolbar_v, os.path.join(basepath,"icons", 'img_buscar.png'), 'Buscar', self.h_buscar, True, False, True, True, None, None, self.iface.mainWindow())
            self.iface.mapCanvas().setMapTool(None)
        else:
            try:
                self.toolbar_h.deleteLater()
                self.toolbar_v.deleteLater()
                main_window = self.iface.mainWindow()
            except:
                pass
        self.h_seleccion()

    def agregar_herramienta(self, toolbar, icon_path, text, callback, enabled_flag, checkable_flag, add_to_menu, add_to_toolbar, status_tip, whats_this, parent):
        try:
            icon = QIcon(icon_path)
            action = QAction(icon, text, parent)
            action.triggered.connect(callback)
            action.setEnabled(enabled_flag)
            action.setCheckable(checkable_flag)
            if status_tip is not None:
                action.setStatusTip(status_tip)
            if whats_this is not None:
                action.setWhatsThis(whats_this)
            if add_to_toolbar:
                toolbar.addAction(action)
            if add_to_menu:
                #self.iface.addPluginToVectorMenu(self.menu, action)
                pass
            self.actions.append(action)
            return action
        except:
            return None

    def unload(self):
        self.iface.removeToolBarIcon(self.gis25m_action)
        try:
            self.toolbar_h.deleteLater()
            self.toolbar_v.deleteLater()
            main_window = self.iface.mainWindow()
            self.iface.mapCanvas().setMapTool(None)
        except:
            pass

    def actualizar_rafam(self):
        str_conexion_rafam = ("DRIVER={Oracle in instantclient10_2};DBQ=10.240.10.101:1521/M25MAYO;UID=usrgis01;PWD=rafgis")
        connection_oracle = pyodbc.connect(str_conexion_rafam)
        cursor = connection_oracle.cursor()
        cursor.execute("SELECT * FROM owner_rafam.ING_VIS_GIS_INMUEBLES")
        rs = cursor.fetchall()
        cursor.close()
        
        connection_postgres = psycopg2.connect(host="10.240.10.16",port="5432",database="gis",user="postgres",password="muni25")
        cursor = connection_postgres.cursor()
        cursor.execute('TRUNCATE TABLE public.rafam')

        #f = open('c:/gis/rafam.txt','w')
        for r in range (0, len(rs)):
            str_linea=''
            for c in range (0, len(rs[0])):
                if c==0 or c==2 or c==4 or c==6 or c==8 or c==10 or c==13 or c==14 or c==17 or c==18:
                    if rs[r][c]==None:
                        str_linea = str_linea + "0,"
                    else:
                        str_linea = str_linea + str(rs[r][c]).replace(",",".") + ","
                else:
                    if rs[r][c]==None:
                        str_linea = str_linea + "'',"
                    else:
                        str_linea = str_linea + "'" + str(rs[r][c]).replace("'","") + "',"
            str_linea = str_linea[:-1]
            #f.writelines(str_linea + "\n")
            try:
                cursor.execute('INSERT INTO public.rafam (circuns, seccion, chacra_nro, chacra_let, quinta_nro, quinta_let, fraccion_nro, fraccion_let, manzana_nro, manzana_let, parcela_nro, parcela_let, subparcela, nro_inmueble, tipo, desc_tipo, contribuyente, sup_terreno, val_fiscal, medidor_luz, partida_provincial, serv_publicos, nose, red_vial) VALUES (' + str_linea + ')')
                #connection_postgres.commit()
            except:
                QMessageBox.information(None, 'Gis25Mayo', 'INSERT INTO public.rafam (circuns, seccion, chacra_nro, chacra_let, quinta_nro, quinta_let, fraccion_nro, fraccion_let, manzana_nro, manzana_let, parcela_nro, parcela_let, subparcela, nro_inmueble, tipo, desc_tipo, contribuyente, sup_terreno, val_fiscal, medidor_luz, partida_provincial, serv_publicos, nose, red_vial) VALUES (' + str_linea + ')')
                #connection_postgres.rollback()
                return
                
        cursor.execute("UPDATE public.rafam SET pda='109' || RIGHT('00000' || partida_provincial,6)")
        connection_postgres.commit()
        #f.close()

    def h_login(self, str_conexion_seguridad):

        from .frm_login import frmLogin
        dialogo = frmLogin(self.version, str_conexion_seguridad, self.nombre_usuario)
        dialogo.exec()
        self.id_usuario_sistema = dialogo.id_usuario_sistema
        self.tipo_usuario = dialogo.tipo_usuario

        dialogo.close()
        if str(self.tipo_usuario)=='4':
            #deshabilito los botones
            self.toolbar_p.setEnabled(False)
            for action in self.actions:
                #if str(action.text())=='Verificar Red':
                #    action.setEnabled(False)
                #if str(action.text())=='Nodo':
                #    action.setEnabled(False)
                #if str(action.text())=='Linea':
                #    action.setEnabled(False)
                #if str(action.text())=='Poste':
                #    action.setEnabled(False)
                if str(action.text())=='Girar':
                    action.setEnabled(False)
                if str(action.text())=='Mover':
                    action.setEnabled(False)
                if str(action.text())=='Rotar':
                    action.setEnabled(False)
                if str(action.text())=='Agregar Vertice':
                    action.setEnabled(False)
                if str(action.text())=='Borrar Vertice':
                    action.setEnabled(False)
                #if str(action.text())=='Conectar':
                #    action.setEnabled(False)
                #if str(action.text())=='Area':
                #    action.setEnabled(False)
                if str(action.text())=='Parcela':
                    action.setEnabled(False)
                if str(action.text())=='Borrar':
                    action.setEnabled(False)
                #if str(action.text())=='Contingencias':
                #    action.setEnabled(False)
                #if str(action.text())=='Usuarios Nuevos':
                #    action.setEnabled(False)
            self.m_administrador.setEnabled(False)

    def h_elementos_seleccionados(self):
        from .frm_seleccion import frmSeleccion
        self.dialogo = frmSeleccion(self.iface.mapCanvas())
        self.dialogo.show()

    def h_buscar(self):
        return
        from .frm_buscar import frmBuscar
        self.dialogo = frmBuscar(self.iface.mapCanvas(), self.conn)
        self.dialogo.show()

    def h_datos_seleccion(self):
        from .frm_datos_seleccion import frmDatosSeleccion
        self.dialogo = frmDatosSeleccion(self.tipo_usuario, self.iface.mapCanvas(), self.conn)
        self.dialogo.show()









    def h_seleccion(self):
        from .herr_seleccion import herrSeleccion
        tool = herrSeleccion(self.modelo, self.tipo_usuario, self.iface.mapCanvas(), self.iface, self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        seleccion_px = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_seleccion.png'))
        seleccion_px.setMask(seleccion_px.mask())
        seleccion_cursor = QtGui.QCursor(seleccion_px)
        self.iface.mapCanvas().setCursor(seleccion_cursor)









    def h_seleccion_aleatoria(self):
        from .herr_seleccion_aleatoria import herrSeleccionAleatoria
        tool = herrSeleccionAleatoria(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        seleccion_px = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_seleccion_aleatoria.png'))
        seleccion_px.setMask(seleccion_px.mask())
        seleccion_cursor = QtGui.QCursor(seleccion_px)
        self.iface.mapCanvas().setCursor(seleccion_cursor)
        
    def h_seleccion_circular(self):
        from .herr_seleccion_circular import herrSeleccionCircular
        tool = herrSeleccionCircular(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        seleccion_px = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_seleccion_circular.png'))
        seleccion_px.setMask(seleccion_px.mask())
        seleccion_cursor = QtGui.QCursor(seleccion_px)
        self.iface.mapCanvas().setCursor(seleccion_cursor)

    def h_nodo(self):
        from .herr_nodo import herrNodo
        self.tension = self.cmbTension.currentText()
        #QMessageBox.information(None, 'h_nodo', str(tension))
        tool = herrNodo(self.modelo, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punNodo = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punNodo.setMask(punNodo.mask())
        curNodo = QtGui.QCursor(punNodo)
        self.iface.mapCanvas().setCursor(curNodo)

    def h_girar(self):
        self.ftrs_nodos = []
        self.ftrs_postes = []
        self.angulo = 0
        #self.nodos_temp = QgsVectorLayer()

        n = self.mapCanvas.layerCount()
        layers = [self.mapCanvas.layer(i) for i in range(n)]
        for lyr in layers:
            if lyr.name()[:5] == 'Nodos' and lyr.name() != 'Nodos_Temp':
                for ftr in lyr.selectedFeatures():
                    self.ftrs_nodos.append(ftr.id())
            if lyr.name()[:6] == 'Postes':
                for ftr in lyr.selectedFeatures():
                    self.ftrs_postes.append(ftr.id())

        if len(self.ftrs_nodos) > 0 or len(self.ftrs_postes) > 0:
            from .frm_girar import frmGirar
            self.dialogo = frmGirar(self.mapCanvas, self.conn, self.ftrs_nodos, self.ftrs_postes)
            self.dialogo.setWindowFlags(self.dialogo.windowFlags() & Qt.CustomizeWindowHint)
            self.dialogo.setWindowFlags(self.dialogo.windowFlags() & ~Qt.WindowMinMaxButtonsHint)
            self.dialogo.show()

    def h_linea(self):
        from .herr_linea import herrLinea
        self.tension = self.cmbTension.currentText()
        #QMessageBox.information(None, 'h_linea', str(tension))
        tool = herrLinea(self.modelo, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.iface.mapCanvas().setCursor(curLinea)
        
    def h_agregar_vertice(self):
        from .herr_agregar_vertice import herrAgregarVertice
        tool = herrAgregarVertice(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punNodo = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punNodo.setMask(punNodo.mask())
        curNodo = QtGui.QCursor(punNodo)
        self.iface.mapCanvas().setCursor(curNodo)

    def h_quitar_vertice(self):
        from .herr_quitar_vertice import herrQuitarVertice
        tool = herrQuitarVertice(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punNodo = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punNodo.setMask(punNodo.mask())
        curNodo = QtGui.QCursor(punNodo)
        self.iface.mapCanvas().setCursor(curNodo)

    def h_poste(self):
        from .herr_poste import herrPoste
        self.tension = self.cmbTension.currentText()
        #QMessageBox.information(None, 'h_poste', str(tension))
        tool = herrPoste(self.modelo, self.tipo_usuario, self.iface.mapCanvas(), self.conn, self.tension)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punPoste = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_nodo.png'))
        punPoste.setMask(punPoste.mask())
        curPoste = QtGui.QCursor(punPoste)
        self.iface.mapCanvas().setCursor(curPoste)

    def h_mover(self):
        from .herr_mover import herrMover
        tool = herrMover(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punMover = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_mover.png'))
        punMover.setMask(punMover.mask())
        curMover = QtGui.QCursor(punMover)
        self.iface.mapCanvas().setCursor(curMover)

    def h_rotar(self):
        from .herr_rotar import herrRotar
        tool = herrRotar(self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punRotar = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_rotar.png'))
        punRotar.setMask(punRotar.mask())
        curRotar = QtGui.QCursor(punRotar)
        self.iface.mapCanvas().setCursor(curRotar)

    def h_area(self):
        from .herr_area import herrArea
        tool = herrArea(self.tipo_usuario, self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.iface.mapCanvas().setCursor(curLinea)

    def h_parcela(self):
        from .herr_parcela import herrParcela
        tool = herrParcela(self.tipo_usuario, self.iface.mapCanvas(), self.conn)
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punLinea = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_linea.png'))
        punLinea.setMask(punLinea.mask())
        curLinea = QtGui.QCursor(punLinea)
        self.iface.mapCanvas().setCursor(curLinea)

    def h_borrar(self):
        ftrs_nodos = []
        ftrs_lineas = []
        ftrs_postes = []
        ftrs_areas = []
        capas = []
        n = self.iface.mapCanvas().layerCount()
        layers = [self.iface.mapCanvas().layer(i) for i in range(n)]
        str_nodos = '0'
        str_lineas = '0'
        str_postes = '0'
        str_areas = '0'
        for lyr in layers:
            if lyr.name()[:5] == 'Nodos' and lyr.name()!='Nodos_Temp':
                for ftr in lyr.selectedFeatures():
                    ftrs_nodos.append(ftr.id())
                    str_nodos = str_nodos + ',' + str(ftr.id())
                    b_existe=False
                    for capa in capas:
                        if capa==lyr:
                            b_existe=True
                    if b_existe==False:
                        capas.append(lyr)
            if lyr.name()[:6] == 'Lineas' and lyr.name()!='Lineas_Temp':
                for ftr in lyr.selectedFeatures():
                    ftrs_lineas.append(ftr.id())
                    str_lineas = str_lineas + ',' + str(ftr.id())
                    b_existe=False
                    for capa in capas:
                        if capa==lyr:
                            b_existe=True
                    if b_existe==False:
                        capas.append(lyr)
            if lyr.name()[:6] == 'Postes':
                for ftr in lyr.selectedFeatures():
                    ftrs_postes.append(ftr.id())
                    str_postes = str_postes + ',' + str(ftr.id())
                    b_existe=False
                    for capa in capas:
                        if capa==lyr:
                            b_existe=True
                    if b_existe==False:
                        capas.append(lyr)
            if lyr.name() == 'Areas':
                for ftr in lyr.selectedFeatures():
                    ftrs_areas.append(ftr.id())
                    str_areas = str_areas + ',' + str(ftr.id())
                    b_existe=False
                    for capa in capas:
                        if capa==lyr:
                            b_existe=True
                    if b_existe==False:
                        capas.append(lyr)
        if len(ftrs_nodos) + len(ftrs_lineas) + len(ftrs_postes) + len(ftrs_areas) > 0:
            if len(capas)==1:
                reply = QMessageBox.question(None, 'OCEBAgis', 'Desea borrar los elementos seleccionados ?', QMessageBox.Yes, QMessageBox.No)
                if reply == QMessageBox.No:
                    return
                layers = [self.iface.mapCanvas().layer(i) for i in range(n)]
                for lyr in layers:
                    if lyr.name()[:6] == 'Lineas' and lyr.name()!='Lineas_Temp':
                        cursor = self.conn.cursor()
                        try:
                            cursor.execute("DELETE FROM Lineas WHERE Geoname IN (" + str_lineas + ")")
                            self.conn.commit()
                        except:
                            self.conn.rollback()
                            QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Lineas !")
                        lyr.triggerRepaint()
                    elif lyr.name()[:5] == 'Nodos' and lyr.name()!='Nodos_Temp':
                        cursor = self.conn.cursor()
                        try:
                            cursor.execute("DELETE FROM Nodos WHERE Geoname IN (" + str_nodos + ")")
                            self.conn.commit()
                        except:
                            self.conn.rollback()
                            QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Nodos !")
                        lyr.triggerRepaint()
                    elif lyr.name()[:6] == 'Postes':
                        cursor = self.conn.cursor()
                        try:
                            cursor.execute("DELETE FROM Postes WHERE Geoname IN (" + str_postes + ")")
                            self.conn.commit()
                        except:
                            self.conn.rollback()
                            QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Postes !")
                        lyr.triggerRepaint()
                    elif lyr.name() == 'Areas':
                        cursor = self.conn.cursor()
                        try:
                            cursor.execute("DELETE FROM Areas WHERE Geoname IN (" + str_areas + ")")
                            self.conn.commit()
                        except:
                            self.conn.rollback()
                            QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Areas !")
                        lyr.triggerRepaint()
                    else:
                        #lyr.triggerRepaint()
                        pass
            else:
                from .frm_borrar import frmBorrar
                dialogo = frmBorrar(capas)
                dialogo.exec()
                capas=dialogo.capas
                dialogo.close()

                if len(capas)==0:
                    return

                layers = [self.iface.mapCanvas().layer(i) for i in range(n)]
                for lyr in layers:
                    if lyr.name()[:6] == 'Lineas' and lyr.name()!='Lineas_Temp':
                        for capa in capas:
                            if capa==lyr.name():
                                str_tension = lyr.name() [7 - len(lyr.name()):]
                                if str_tension.strip() == 'Proyectos':
                                    str_tension='0'
                                cursor = self.conn.cursor()
                                try:
                                    cursor.execute("DELETE FROM Lineas WHERE Tension=" + str_tension + " AND Geoname IN (" + str_lineas + ")")
                                    self.conn.commit()
                                except:
                                    self.conn.rollback()
                                    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Lineas !")
                                lyr.triggerRepaint()
                    elif lyr.name()[:5] == 'Nodos' and lyr.name()!='Nodos_Temp':
                        for capa in capas:
                            if capa==lyr.name():
                                str_tension = lyr.name() [6 - len(lyr.name()):]
                                if str_tension.strip() == 'Proyectos':
                                    str_tension='0'
                                cursor = self.conn.cursor()
                                try:
                                    cursor.execute("DELETE FROM Nodos WHERE Tension=" + str_tension + " AND Geoname IN (" + str_nodos + ")")
                                    self.conn.commit()
                                except:
                                    self.conn.rollback()
                                    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Nodos !")
                                lyr.triggerRepaint()
                    elif lyr.name()[:6] == 'Postes':
                        for capa in capas:
                            if capa==lyr.name():
                                str_tension = lyr.name() [7 - len(lyr.name()):]
                                if str_tension.strip() == 'Proyectos':
                                    str_tension='0'
                                cursor = self.conn.cursor()
                                try:
                                    cursor.execute("DELETE FROM Postes WHERE Tension=" + str_tension + " AND Geoname IN (" + str_postes + ")")
                                    self.conn.commit()
                                except:
                                    self.conn.rollback()
                                    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Postes !")
                                lyr.triggerRepaint()
                    elif lyr.name() == 'Areas':
                        for capa in capas:
                            if capa=='Areas':
                                cursor = self.conn.cursor()
                                try:
                                    cursor.execute("DELETE FROM Areas WHERE Geoname IN (" + str_areas + ")")
                                    self.conn.commit()
                                except:
                                    self.conn.rollback()
                                    QMessageBox.warning(None, 'Gis 25 de Mayo', "No se pudieron borrar Areas !")
                                lyr.triggerRepaint()
            return

    def ejecutar_sql(self):
        from .frm_sql import frmSql
        self.dialogo = frmSql(self.iface.mapCanvas, self.conn)
        self.dialogo.show()

    def h_zoomIn(self):
        from .herr_zoom import herrZoom
        tool = herrZoom(self.iface.mapCanvas(), 'ZoomIn')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_zoom_in.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.iface.mapCanvas().setCursor(curZoom)

    def h_zoomOut(self):
        from .herr_zoom import herrZoom
        tool = herrZoom(self.iface.mapCanvas(), 'ZoomOut')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_zoom_out.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.iface.mapCanvas().setCursor(curZoom)
        
    def h_Pan(self):
        from .herr_zoom import herrZoom
        tool = herrZoom(self.iface.mapCanvas(), 'Pan')
        self.iface.mapCanvas().setMapTool(tool)
        #Cambio el cursor
        punZoom = QtGui.QPixmap(os.path.join(basepath,"icons", 'cur_pan.png'))
        punZoom.setMask(punZoom.mask())
        curZoom = QtGui.QCursor(punZoom)
        self.iface.mapCanvas().setCursor(curZoom)
